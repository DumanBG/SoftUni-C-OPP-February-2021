﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    public class Fruit : Vegetable
    {
        public Fruit(int qunatity) 
            : base(qunatity)
        {
        }
    }
}
